#include <stdio.h>
#include <stdlib.h>

int x = 8;

void mostrar();
int main()
{
    printf("La global desde el main %d\n", x);
    mostrar();
    printf("La global desde el main %d\n", x);


    return 0;
}

void mostrar()
{

    x = 9;
    printf("La global desde la funcion %d", x);

}
