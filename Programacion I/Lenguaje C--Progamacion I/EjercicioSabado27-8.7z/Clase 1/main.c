#include <stdio.h>
#include <stdlib.h>
#include <conio.h>



float calcularPorcentaje(int cont, int total);
int validarEntero(int dato, int min, int max);
int main()
{

    int legajo;
    int nota;
    char sexo;
    int contMasc = 0;
    int contFem = 0;
    int contTotal = 0;
    int contAprobados = 0;
    float porcentajeAprobados;
    float porcentajeMasculinos;
    float porcentajeFemeninos;
    int maximaNota;
    int maxLegajo;
    char maxSexo;
    int flag = 0;

    char seguir = 's';

    do
    {
        printf("Ingrese legajo: ");
        scanf("%d", &legajo);

        legajo = validarEntero(legajo, 1, 100);

        printf("Ingrese sexo: ");
        sexo = getche();
        while(sexo!='f' && sexo!='m')
        {
            printf("Reingrese sexo: ");
            sexo = getche();
        }

        printf("Ingrese nota: ");
        scanf("%d", &nota);

        nota = validarEntero(nota, 1, 10);


        if(sexo=='f')
        {
            contFem++;
        }
        else
        {
            contMasc++;
        }

        if(nota>4)
        {
            contAprobados++;
        }

        if(flag==0 || nota>maximaNota)
        {
            maximaNota = nota;
            maxLegajo = legajo;
            maxSexo = sexo;
            flag = 1;
        }

        contTotal++;
        printf("Desea ingresar otro alumno? (s/n) ");
        fflush(stdin);
        scanf("%c", &seguir);

    }
    while(seguir=='s');

    porcentajeAprobados = calcularPorcentaje(contAprobados, contTotal);
    porcentajeFemeninos = calcularPorcentaje(contFem, contTotal);
    //(float) (contFem * 100)/contTotal;
    porcentajeMasculinos = 100 - porcentajeFemeninos;
    printf("La cantidad de hombres es: %d\nLa cantidad de mujeres es: %d\n", contMasc, contFem);
    printf("El porcentaje de aprobados es: %.2f%c", porcentajeAprobados, 37);
    printf("El porcentaje de mujeres es: %.2f%c\nEl porcentaje de hombres es: %.2f%c\n", porcentajeFemeninos, 37, porcentajeMasculinos, 37);
    printf("El alumno con maxima nota es:\n\tLegajo: %d\n\tSexo:%c\n\tNota: %d", maxLegajo, maxSexo, maximaNota);




    return 0;
}

float calcularPorcentaje(int cont, int total)
{
    float porcentaje;

    porcentaje = (float)(cont * 100)/total;


    return porcentaje;

}
int validarEntero(int dato, int min, int max)
{
    while(dato<min || dato>max)
    {
        printf("Error!!! Reingrese: ");
        scanf("%d", &dato);
    }

    return dato;
}
