﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio3
{
    class Program
    {
        static void Main(string[] args)
        {
            int j;
            int contador = 0;
            Console.WriteLine("Ingrese un numero: ");
            int numero = Int32.Parse(Console.ReadLine());
            for(int i=1; i<numero ;i++)
            {

                for (j= numero; j >= 1; j--)
                {
                    if (j % i == 0)
                    {
                        contador++;

                    }

                }

                if (contador == 2)
                {
                    Console.WriteLine("{0}", i);

                }

            }
            Console.ReadLine();



        }
    }
}
