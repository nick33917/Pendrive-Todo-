﻿namespace ManejadoreEventosClase21
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCantidadRetirar = new System.Windows.Forms.Label();
            this.txtCantidad = new System.Windows.Forms.TextBox();
            this.lblBilleteDosPesos = new System.Windows.Forms.Label();
            this.lblBilleteCincoPesos = new System.Windows.Forms.Label();
            this.lblBilleteDiezPesos = new System.Windows.Forms.Label();
            this.lblBilleteVeintePesos = new System.Windows.Forms.Label();
            this.lblBilleteCincuentaPesos = new System.Windows.Forms.Label();
            this.lblBilleteCienPesos = new System.Windows.Forms.Label();
            this.txtBilleteDos = new System.Windows.Forms.TextBox();
            this.txtBilleteCinco = new System.Windows.Forms.TextBox();
            this.txtBilleteDiez = new System.Windows.Forms.TextBox();
            this.txtBilleteVeinte = new System.Windows.Forms.TextBox();
            this.txtBilleteCincuenta = new System.Windows.Forms.TextBox();
            this.txtBilleteCien = new System.Windows.Forms.TextBox();
            this.btnAceptar = new System.Windows.Forms.Button();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.btnSalir = new System.Windows.Forms.Button();
            this.grbCantidad = new System.Windows.Forms.GroupBox();
            this.grbBilletes = new System.Windows.Forms.GroupBox();
            this.grbCantidad.SuspendLayout();
            this.grbBilletes.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblCantidadRetirar
            // 
            this.lblCantidadRetirar.AutoSize = true;
            this.lblCantidadRetirar.Location = new System.Drawing.Point(6, 33);
            this.lblCantidadRetirar.Name = "lblCantidadRetirar";
            this.lblCantidadRetirar.Size = new System.Drawing.Size(87, 13);
            this.lblCantidadRetirar.TabIndex = 1;
            this.lblCantidadRetirar.Text = "Cantidad a retirar";
            // 
            // txtCantidad
            // 
            this.txtCantidad.Location = new System.Drawing.Point(125, 30);
            this.txtCantidad.Name = "txtCantidad";
            this.txtCantidad.Size = new System.Drawing.Size(100, 20);
            this.txtCantidad.TabIndex = 2;
            // 
            // lblBilleteDosPesos
            // 
            this.lblBilleteDosPesos.AutoSize = true;
            this.lblBilleteDosPesos.Location = new System.Drawing.Point(6, 28);
            this.lblBilleteDosPesos.Name = "lblBilleteDosPesos";
            this.lblBilleteDosPesos.Size = new System.Drawing.Size(70, 13);
            this.lblBilleteDosPesos.TabIndex = 4;
            this.lblBilleteDosPesos.Text = "Billetes de $2";
            // 
            // lblBilleteCincoPesos
            // 
            this.lblBilleteCincoPesos.AutoSize = true;
            this.lblBilleteCincoPesos.Location = new System.Drawing.Point(6, 61);
            this.lblBilleteCincoPesos.Name = "lblBilleteCincoPesos";
            this.lblBilleteCincoPesos.Size = new System.Drawing.Size(70, 13);
            this.lblBilleteCincoPesos.TabIndex = 5;
            this.lblBilleteCincoPesos.Text = "Billetes de $5";
            // 
            // lblBilleteDiezPesos
            // 
            this.lblBilleteDiezPesos.AutoSize = true;
            this.lblBilleteDiezPesos.Location = new System.Drawing.Point(6, 94);
            this.lblBilleteDiezPesos.Name = "lblBilleteDiezPesos";
            this.lblBilleteDiezPesos.Size = new System.Drawing.Size(76, 13);
            this.lblBilleteDiezPesos.TabIndex = 6;
            this.lblBilleteDiezPesos.Text = "Billetes de $10";
            // 
            // lblBilleteVeintePesos
            // 
            this.lblBilleteVeintePesos.AutoSize = true;
            this.lblBilleteVeintePesos.Location = new System.Drawing.Point(6, 127);
            this.lblBilleteVeintePesos.Name = "lblBilleteVeintePesos";
            this.lblBilleteVeintePesos.Size = new System.Drawing.Size(76, 13);
            this.lblBilleteVeintePesos.TabIndex = 7;
            this.lblBilleteVeintePesos.Text = "Billetes de $20";
            // 
            // lblBilleteCincuentaPesos
            // 
            this.lblBilleteCincuentaPesos.AutoSize = true;
            this.lblBilleteCincuentaPesos.Location = new System.Drawing.Point(6, 160);
            this.lblBilleteCincuentaPesos.Name = "lblBilleteCincuentaPesos";
            this.lblBilleteCincuentaPesos.Size = new System.Drawing.Size(76, 13);
            this.lblBilleteCincuentaPesos.TabIndex = 8;
            this.lblBilleteCincuentaPesos.Text = "Billetes de $50";
            // 
            // lblBilleteCienPesos
            // 
            this.lblBilleteCienPesos.AutoSize = true;
            this.lblBilleteCienPesos.Location = new System.Drawing.Point(6, 193);
            this.lblBilleteCienPesos.Name = "lblBilleteCienPesos";
            this.lblBilleteCienPesos.Size = new System.Drawing.Size(82, 13);
            this.lblBilleteCienPesos.TabIndex = 9;
            this.lblBilleteCienPesos.Text = "Billetes de $100";
            this.lblBilleteCienPesos.Click += new System.EventHandler(this.lblBilleteCienPesos_Click);
            // 
            // txtBilleteDos
            // 
            this.txtBilleteDos.Location = new System.Drawing.Point(125, 19);
            this.txtBilleteDos.Name = "txtBilleteDos";
            this.txtBilleteDos.ReadOnly = true;
            this.txtBilleteDos.Size = new System.Drawing.Size(100, 20);
            this.txtBilleteDos.TabIndex = 10;
            // 
            // txtBilleteCinco
            // 
            this.txtBilleteCinco.Location = new System.Drawing.Point(125, 54);
            this.txtBilleteCinco.Name = "txtBilleteCinco";
            this.txtBilleteCinco.ReadOnly = true;
            this.txtBilleteCinco.Size = new System.Drawing.Size(100, 20);
            this.txtBilleteCinco.TabIndex = 11;
            // 
            // txtBilleteDiez
            // 
            this.txtBilleteDiez.Location = new System.Drawing.Point(125, 87);
            this.txtBilleteDiez.Name = "txtBilleteDiez";
            this.txtBilleteDiez.ReadOnly = true;
            this.txtBilleteDiez.Size = new System.Drawing.Size(100, 20);
            this.txtBilleteDiez.TabIndex = 12;
            // 
            // txtBilleteVeinte
            // 
            this.txtBilleteVeinte.Location = new System.Drawing.Point(125, 120);
            this.txtBilleteVeinte.Name = "txtBilleteVeinte";
            this.txtBilleteVeinte.ReadOnly = true;
            this.txtBilleteVeinte.Size = new System.Drawing.Size(100, 20);
            this.txtBilleteVeinte.TabIndex = 13;
            // 
            // txtBilleteCincuenta
            // 
            this.txtBilleteCincuenta.Location = new System.Drawing.Point(125, 153);
            this.txtBilleteCincuenta.Name = "txtBilleteCincuenta";
            this.txtBilleteCincuenta.ReadOnly = true;
            this.txtBilleteCincuenta.Size = new System.Drawing.Size(100, 20);
            this.txtBilleteCincuenta.TabIndex = 13;
            // 
            // txtBilleteCien
            // 
            this.txtBilleteCien.Location = new System.Drawing.Point(125, 186);
            this.txtBilleteCien.Name = "txtBilleteCien";
            this.txtBilleteCien.ReadOnly = true;
            this.txtBilleteCien.Size = new System.Drawing.Size(100, 20);
            this.txtBilleteCien.TabIndex = 13;
            // 
            // btnAceptar
            // 
            this.btnAceptar.Location = new System.Drawing.Point(297, 12);
            this.btnAceptar.Name = "btnAceptar";
            this.btnAceptar.Size = new System.Drawing.Size(75, 23);
            this.btnAceptar.TabIndex = 14;
            this.btnAceptar.Text = "Aceptar";
            this.btnAceptar.UseVisualStyleBackColor = true;
            this.btnAceptar.Click += new System.EventHandler(this.btnAceptar_Click);
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.Location = new System.Drawing.Point(297, 48);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(75, 23);
            this.btnLimpiar.TabIndex = 14;
            this.btnLimpiar.Text = "Limpiar";
            this.btnLimpiar.UseVisualStyleBackColor = true;
            this.btnLimpiar.Click += new System.EventHandler(this.btnLimpiar_Click);
            // 
            // btnSalir
            // 
            this.btnSalir.Location = new System.Drawing.Point(297, 285);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(75, 23);
            this.btnSalir.TabIndex = 14;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // grbCantidad
            // 
            this.grbCantidad.Controls.Add(this.lblCantidadRetirar);
            this.grbCantidad.Controls.Add(this.txtCantidad);
            this.grbCantidad.Location = new System.Drawing.Point(12, 12);
            this.grbCantidad.Name = "grbCantidad";
            this.grbCantidad.Size = new System.Drawing.Size(243, 70);
            this.grbCantidad.TabIndex = 15;
            this.grbCantidad.TabStop = false;
            this.grbCantidad.Text = "Cantidad a retirar";
            // 
            // grbBilletes
            // 
            this.grbBilletes.Controls.Add(this.lblBilleteDosPesos);
            this.grbBilletes.Controls.Add(this.lblBilleteCincoPesos);
            this.grbBilletes.Controls.Add(this.lblBilleteDiezPesos);
            this.grbBilletes.Controls.Add(this.lblBilleteVeintePesos);
            this.grbBilletes.Controls.Add(this.lblBilleteCincuentaPesos);
            this.grbBilletes.Controls.Add(this.txtBilleteCien);
            this.grbBilletes.Controls.Add(this.lblBilleteCienPesos);
            this.grbBilletes.Controls.Add(this.txtBilleteCincuenta);
            this.grbBilletes.Controls.Add(this.txtBilleteDos);
            this.grbBilletes.Controls.Add(this.txtBilleteVeinte);
            this.grbBilletes.Controls.Add(this.txtBilleteCinco);
            this.grbBilletes.Controls.Add(this.txtBilleteDiez);
            this.grbBilletes.Location = new System.Drawing.Point(12, 88);
            this.grbBilletes.Name = "grbBilletes";
            this.grbBilletes.Size = new System.Drawing.Size(243, 220);
            this.grbBilletes.TabIndex = 16;
            this.grbBilletes.TabStop = false;
            this.grbBilletes.Text = "Cantidad de billetes";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 319);
            this.Controls.Add(this.grbBilletes);
            this.Controls.Add(this.grbCantidad);
            this.Controls.Add(this.btnSalir);
            this.Controls.Add(this.btnLimpiar);
            this.Controls.Add(this.btnAceptar);
            this.Name = "Form1";
            this.Text = "Form1";
            this.grbCantidad.ResumeLayout(false);
            this.grbCantidad.PerformLayout();
            this.grbBilletes.ResumeLayout(false);
            this.grbBilletes.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label lblCantidadRetirar;
        private System.Windows.Forms.TextBox txtCantidad;
        private System.Windows.Forms.Label lblBilleteDosPesos;
        private System.Windows.Forms.Label lblBilleteCincoPesos;
        private System.Windows.Forms.Label lblBilleteDiezPesos;
        private System.Windows.Forms.Label lblBilleteVeintePesos;
        private System.Windows.Forms.Label lblBilleteCincuentaPesos;
        private System.Windows.Forms.Label lblBilleteCienPesos;
        private System.Windows.Forms.TextBox txtBilleteDos;
        private System.Windows.Forms.TextBox txtBilleteCinco;
        private System.Windows.Forms.TextBox txtBilleteDiez;
        private System.Windows.Forms.TextBox txtBilleteVeinte;
        private System.Windows.Forms.TextBox txtBilleteCincuenta;
        private System.Windows.Forms.TextBox txtBilleteCien;
        private System.Windows.Forms.Button btnAceptar;
        private System.Windows.Forms.Button btnLimpiar;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.GroupBox grbCantidad;
        private System.Windows.Forms.GroupBox grbBilletes;
    }
}

