﻿public enum EOperaciones
{
    Sumar,
    Restar,
    Multiplicar,
    Dividir
}