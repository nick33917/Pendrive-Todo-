﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
namespace Entidades.SP
{
    [XmlInclude(typeof(DepositoHeredado))]
    [XmlInclude(typeof(Deposito))]
    public class Deposito
    {
        public Producto[] productos;
      
        public Deposito()
            : this(3)
        {
        }

        public Deposito(int cant)
        {
            this.productos = new Producto[cant];
        }





        public static Producto[] operator +(Deposito d1, Deposito d2)
        {
            int cant = d1.productos.Length + d2.productos.Length;
            Producto[] array = new Producto[cant];

            d1.productos.CopyTo(array, 0);
            d2.productos.CopyTo(array, d1.productos.Length);

            for (int i = 0; i < array.Length - 1; i++)
            {
                for (int j = i + 1; j < array.Length; j++)
                {
                    if (array[i] != null && array[j] != null)
                    {
                        if (array[i].nombre == array[j].nombre)
                        {
                            array[i].stock = array[i].stock + array[j].stock;
                            array[j] = null;
                        }
                    }
                }
            }

            return array;

            
        }
    }
}